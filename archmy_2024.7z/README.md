Этот скрипт специально разработан для моей машины, и никто, кроме меня, не должен его использовать.

Запустите скрипт с помощью следующей команды:

`curl https://gitlab.com/bacteria-scripts/archlinux-install-script/raw/master/install_rus.sh > install_rus.sh`

Введите идентификатор пользователя Arch Linux в ISO, введите iwd console, используя `iwctl`, а затем подключитесь с помощью:

`станция <интерфейс> подключается <SSID>"

После завершения установки перезагрузитесь и подключитесь к Wi-Fi с помощью:

`nmcli device wifi connect <SSID> пароль <password>`



This script is highly customised for my machine and no one should use it except me.

Get the script using the following command:

`curl https://gitlab.com/bacteria-scripts/archlinux-install-script/raw/master/install_rus.sh > install_rus.sh`

Arch Linux uses iwd in ISO, enter iwd console using `iwctl` and then connect using:

`station <interface> connect <SSID>`

Once installation is done, reboot and connect to wifi using:

`nmcli device wifi connect <SSID> password <password>`
