#!/bin/bash
wget git.io/archuefi3.sh && sh archuefi3.sh
